package com.example.domains.contracts.services;

import com.example.domains.entities.Payment;

public interface PaymentService extends ProjectionDomainService<Payment, Integer>{

}

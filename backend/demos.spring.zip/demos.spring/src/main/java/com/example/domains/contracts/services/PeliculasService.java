package com.example.domains.contracts.services;

import com.example.domains.entities.Film;

public interface PeliculasService extends ProjectionDomainService<Film, Integer> {

}

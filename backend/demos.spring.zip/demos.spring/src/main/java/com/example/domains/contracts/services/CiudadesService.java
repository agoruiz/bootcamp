package com.example.domains.contracts.services;

import com.example.domains.entities.City;

public interface CiudadesService extends ProjectionDomainService<City, Integer> {

}

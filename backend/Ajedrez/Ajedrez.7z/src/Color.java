
public enum Color {	
 Blanco,
 Negro;
}

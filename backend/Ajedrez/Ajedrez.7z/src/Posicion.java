
public class Posicion {
	
private Integer laFila;
private Integer laColumna;

Posicion(Integer fila, Integer columna){
	this.laFila = fila;
	this.laColumna = columna;
	
}
Posicion(char ch1, char ch2){
	
}
public Integer getLaFila() {
	return laFila;
}

public Integer getLaColumna() {
	return laColumna;
}

public Boolean Equals() {
	return false;
}



}

package com.example.domains.contracts.services;

import com.example.domains.entities.Country;

public interface PaisesService extends ProjectionDomainService<Country, Integer> {

}

package com.example.ioc;

public interface Servicio {
	public void run();
	void setName(String value);
}
